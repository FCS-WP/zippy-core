<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

?>

<footer id="site-footer" class="site-footer site-footer--default" role="contentinfo">
    <p class="text-center"><?php echo sprintf(__('%s Created by LaStudio', 'bakerfresh'), date('Y')); ?></p>
</footer>