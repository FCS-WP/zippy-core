<?php
/**
 * This file includes dynamic css
 *
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

return;